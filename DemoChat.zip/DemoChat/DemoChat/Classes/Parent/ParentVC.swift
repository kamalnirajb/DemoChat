//
//  ParentVC.swift
//  DemoChat
//
//  Created by Niraj Kumar on 12/20/16.
//  Copyright © 2016 Niraj. All rights reserved.
//

import UIKit
import SocketIO

class ParentVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        socket.on("chat message") {data, ack in
//            self.socket.emit("my reply", ["this": "this"]);
//        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
